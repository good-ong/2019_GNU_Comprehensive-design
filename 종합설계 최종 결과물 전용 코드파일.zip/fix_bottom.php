<div class="fix_bottom">
  <div id="fix_bottom_logo">
    <a href="index.php"><img src="img/main_2.jpg" style="width:200px; height:120px"></a>
  </div>
  <div id="fix_bottom_copyright">
    <p>
      <strong>홈페이지명</strong> : 세모공 - 세상의 모든 공식<br>
      52828 경상남도 진주시 진주대로 501 경상대학교 354동 4층 수학과<br>
    </p>
    <p><strong>제작자</strong> : 김규동, 이대호, 이승규, 이정우</p>
    <p>Copyright 2019 Semogong. All rights reserved.</p>
  </div>
</div>
</body>
</html>
