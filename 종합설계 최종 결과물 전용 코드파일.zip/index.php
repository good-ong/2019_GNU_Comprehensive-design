<?php require_once("fix_top.php")?>
    <div class="home_center">
      <div id="main">
        <img src="img/메인화면.jpg" style="text-align:center;">
      </div>
      <div>
        <a href="b_notice.php?page=1"><img src="img/공지사항.jpg"></a>
        <a href="course.php?id=초중등"><img src="img/공식.jpg"></a>
        <a href="b_free.php?page=1"><img src="img/게시판.jpg"></a>
      </div>
    </div>
<?php require_once("fix_bottom.php")?>
