<form enctype='multipart/form-data' action='upload_ok.php' method='post'>
	<input type='file' name='myfile'>
	<button>보내기</button>
</form>
